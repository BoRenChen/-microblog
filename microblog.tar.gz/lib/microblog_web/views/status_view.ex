defmodule MicroblogWeb.StatusView do
  use MicroblogWeb, :view
end
